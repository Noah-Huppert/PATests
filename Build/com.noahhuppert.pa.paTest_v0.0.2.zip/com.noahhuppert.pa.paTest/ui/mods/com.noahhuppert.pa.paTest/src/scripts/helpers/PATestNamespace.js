/* Setup "namespace" */
//Setup all "namespaces" in one file before they are ever used
PATest.core = {};
